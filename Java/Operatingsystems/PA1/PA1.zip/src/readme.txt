Jonathan Chu PA1

This package is my attempt at the simple command line environment. 
pwd, cd, ls all work. Cat has an issue printing out all the output.
grep, lc, and history have bugs. 