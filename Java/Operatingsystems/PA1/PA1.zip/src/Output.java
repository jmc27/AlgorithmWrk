import java.util.concurrent.BlockingQueue;


public class Output extends ShellSink{

	public Output(BlockingQueue in) {
		super(in);
		// TODO Auto-generated constructor stub
	}

}
