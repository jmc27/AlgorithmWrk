Jonathan Chu
All the same files from part 1 but Test1.java is replaced by Test2.java and PriorityScheduler.java is used.

Bugs with code. Animals are eating at more than one anthill and I can't figure out why.