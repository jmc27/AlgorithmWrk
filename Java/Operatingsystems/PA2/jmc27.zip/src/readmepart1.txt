Jonathan Chu
PA 2
Part 1
Files: Aardvark.java, Animal.java, Anteater.java, Anthill.java, BasicAnthill.java, Test1.java
In this part of the assignment we are supposed to complete part 1. This entails making 4 anthills, 150 aardvarks,
 and 50 anteaters trying to eat in the order of 50 aardvarks, then 50 anteaters, then the rest of the aardvarks.
 This is accomplished by running Test1.java. For this part of the assignment I created a BasicAnthill class
 and synchronized the run method of Animal. 